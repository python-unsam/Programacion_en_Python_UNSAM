# rebotes.py
# Ejercicio

altura = 100

for i in range(1, 11):
    altura = altura * 3/5
    print(i, round(altura,4))