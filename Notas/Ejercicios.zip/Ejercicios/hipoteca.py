# hipoteca.py
# Archivo de ejemplo
# Ejercicio
