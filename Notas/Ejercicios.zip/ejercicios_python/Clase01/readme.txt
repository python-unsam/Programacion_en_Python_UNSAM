esta carpeta contiene los archivos .py correspondientes a la ejercitación de la clase 1
